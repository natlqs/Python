try:
    import usocket as socket
except:
    import socket

from machine import Pin
import network
'''
import esp
esp.osdebug(none)
'''
import gc
gc.collect()

ssid = '冯威的 iPhone'
password = '87499006'

station =network.WLAN(network.STA_IF)

station.active(True)
station.connect(ssid, password)
while station.isconnected() == False:
    pass

print('Connection successful')
print(station.ifconfig())

led = Pin(18, Pin.OUT)
def web_page():
    html = """<html><head><meta name="viewport"
    content="width=device-width, initial-scale=1"></head><body><h1>Ojay Server</h1><a
    href=\"?led=on\"><button>ON</button></a><a href=\"?led=off\"><button>OFF</button></a></body><html>"""
    return html
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('', 80))
s.listen(5)

while True:
    conn, addr = s.accept()
    print('Got a connection from %s' % str(addr))
    request = conn.recv(1024)
    request = str(request)
    print('Content = %s' % request)
    led_on = request.find('/?led=on')
    led_off= request.find('/?led=off')
    if led_on ==6:
        print('LED ON')
        led.value(1)
    if led_off ==6:
        print('LED OFF')
        led.value(0)
    response = web_page()
    conn.send('HTTP/1.1 200 OK\n')
    conn.send('Content-Type: text/html\n')
    conn.send('Connection: close\n\n')
    conn.send('HTTP/1.1 200 OK\n')
    conn.sendall(response)
    conn.close()