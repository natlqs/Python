from machine import Pin
import time

red = Pin(3, Pin.OUT)
green = Pin(4, Pin.OUT)
blue = Pin(5, Pin.OUT)
cold = Pin(19, Pin.OUT)
warm = Pin(18,Pin.OUT)
while True:
    for i in (red, green, blue, cold, warm):
        i.value(1)
        time.sleep(0.5)
        i.value(0)
        time.sleep(0.5)
    
