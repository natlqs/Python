#  各色灯轮流呼吸
from machine import Pin, PWM
import time

red = Pin(3, Pin.OUT)
green = Pin(4, Pin.OUT)
blue = Pin(5, Pin.OUT)
cold = Pin(19, Pin.OUT)
warm = Pin(18,Pin.OUT)
cold = Pin(19, Pin.OUT)

def breath():
    for i in (red, green, blue, cold, warm):
        pwm = PWM(i)
        freq = pwm.freq()
        pwm.freq(1000)
        for x in range(0, 1024, 1):
            pwm.duty(x)
            time.sleep_ms(1)
        for y in range(1023, -1, -1):
            pwm.duty(y)
            time.sleep_ms(1) 

def blink():
    for i in (red, green, blue, cold, warm):
        i.value(1)
        time.sleep(0.2)
        i.value(0)
        time.sleep(0.2)
        # i.value(1)
        # time.sleep(0.4)
        # i.value(0)
        # time.sleep(0.4)

while True:
    # breath()
    blink()