from machine import Pin, PWM
import time

red = Pin(3, Pin.OUT)
green = Pin(4, Pin.OUT)
blue = Pin(5, Pin.OUT)
cold = Pin(19, Pin.OUT)
warm = Pin(18,Pin.OUT)
cold = Pin(19, Pin.OUT)

pwm_red = PWM(red)      # create PWM object from a pin
freq = pwm_red.freq()      # get current frequency(default 5kHz)
pwm_red.freq(1000)         # set PWM frequency from 1Hz to 40MHz

while True:
    for i in range(0, 1024):
        pwm_red.duty(i)
        time.sleep_ms(1)

    for i in range(1023, -1, -1):
        pwm_red.duty(i)
        time.sleep_ms(1)
