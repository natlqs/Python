from machine import Pin, PWM
import time

red = Pin(3, Pin.OUT)
green = Pin(4, Pin.OUT)
blue = Pin(5, Pin.OUT)
cold = Pin(19, Pin.OUT)
warm = Pin(18,Pin.OUT)


def blink(t):
    for i in (red, green, blue, cold, warm):
        i.value(1)
        time.sleep(t)
        i.value(0)
        time.sleep(t)
    
def breath():
    for i in (red, green, blue, cold, warm):
        led=PWM(i)
        led.freq(1000)
        
        for x in range(0, 1024):
            led.duty(x)
            time.sleep(0.001)
        for y in range(1023, -1, -1):
            led.duty(y)
            time.sleep(0.001)
        
while True:
    #print('hello pwm')
    breath()
    #print('Breath')
    time.sleep(2)
    blink(0.2)